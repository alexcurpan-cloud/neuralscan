# NeuralScan CLI — scan gratuit, 100% local

Scaneaza codul tau pentru vulnerabilitati comune (chei hardcodate, SQL injection,
command injection, crypto slab, ReDoS...) — FARA server, FARA cloud, FARA cont.
Totul ruleaza pe masina ta, codul tau nu pleaca nicaieri.

## Instalare (2 comenzi)

```
# 1. dezarhiveaza
unzip neuralscan-cli.zip

# 2. scaneaza (fisier sau folder)
python3 neuralscan-cli/neuralscan-cli.py codul_meu.py
```

## Exemple

```
python3 neuralscan-cli.py aplicatia_mea.py        # scaneaza 1 fisier
python3 neuralscan-cli.py proiectul_meu/          # scaneaza tot folderul (py/js/ts/html/sql...)
python3 neuralscan-cli.py cod.py --json           # output brut JSON
python3 neuralscan-cli.py cod.py -v               # arata si linia suspecta
```

## Ce iese la iesire?

- 🔴/🟠/🟡/🔵 fiecare problema gasita, cu linia
- 💡 explicatie non-tehnica (ce risc are, de ce conteaza)
- 🔧 fix prompt (ce sa schimbi, cu exemplu)

Exit code: 0 = curat, 1 = probleme gasite, 2 = eroare.

## Cerinte

Doar Python 3.8+. Zero dependinte. Zero internet.
